<?php include("template/cabecera.php"); ?>


<div class="col-md-6">
    <br />
    <div class="jumbotron">

        <h3 class="display-4">Nosotros</h3>
        <p class="lead">Somos una empresa que se dedica a la venta de slider para motocicletas </p>
        <video width="400px" src="./img/pruebas.mp4" controls> Vídeo no es soportado... </video>
 </div>
</div>



<div class="col-md-6">
    <br />
    <div class="jumbotron">

        <h3 class="display-4">Misión</h3>
        <p class="lead">Estamos enfocados a dar el mejor servicio hacia nuestros clientes, dando diseños inovadores, cumpliendo dos base (Diseño, Funcion) </p>


    </div>
    <div class="jumbotron">

        <h3 class="display-4">Contáctanos</h3>
        <p class="lead">Redes de contacto:
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-facebook" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" />
            </svg>
            <a href="https://www.facebook.com/StuntRex.pe" target="_blank">Facebook</a> |
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-instagram" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <rect x="4" y="4" width="16" height="16" rx="4" />
                <circle cx="12" cy="12" r="3" />
                <line x1="16.5" y1="7.5" x2="16.5" y2="7.501" />
            </svg>
            <a href="https://www.instagram.com/stuntracing._/" target="_blank">Instagram</a> | <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-whatsapp" width="40" height="40" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M3 21l1.65 -3.8a9 9 0 1 1 3.4 2.9l-5.05 .9" />
                <path d="M9 10a0.5 .5 0 0 0 1 0v-1a0.5 .5 0 0 0 -1 0v1a5 5 0 0 0 5 5h1a0.5 .5 0 0 0 0 -1h-1a0.5 .5 0 0 0 0 1" />
            </svg>
            <a href="https://wa.link/zqpxo8" target="_blank">whatsapp</a>
        </p>


    </div>
</div>


<?php include("template/pie.php"); ?>