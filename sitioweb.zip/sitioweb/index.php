<?php include("template/cabecera.php"); ?>
           
            <div class="jumbotron text-center">
                <h1 class="display-3"> <b>Bienvenidos a StuntRex</b>     </h1>
                <p class="lead"> <i>tienda de protecciones para motos</i>  </p>
                <hr class="my-2">
                
            <img width="600" src="img/banner2.jpg"  class="img-thumbnail rounded mx-auto d-block" />

                <p>Más información</p>
                <p class="lead">
                    <a class="btn btn-primary btn-lg" href="productos.php" role="button">Ver catalogo  </a>
                </p>
            </div>

<?php include("template/pie.php"); ?>

