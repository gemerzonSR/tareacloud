<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StuntRex </title>
    <link rel="icon" href="stuntracing.ico">

    <link rel="stylesheet" href="./css/bootstrap.css" />
    <link rel="stylesheet" href="./css/fontello.css" />

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <font style="vertical-align: inherit;">
                    <font style="vertical-align: inherit;"><b>STUNTREX</b> </font>
                </font>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Navegación de palanca">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarColor02">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">INICIO
                                </font>
                            </font><span class="visually-hidden">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">(Actual)</font>
                                </font>
                            </span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="productos.php">
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">TIENDA</font>
                            </font>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="nosotros.php">
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">Nosotros</font>
                            </font>
                        </a>
                    </li> <li class="nav-item">
                        <a class="nav-link" href="./administrador/">
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">cuenta</font>
                            </font>
                        </a>
                    </li>
                   
                </ul>
                <form class="d-flex">
                    <input class="form-control me-sm-2" type="text" placeholder="Búsqueda">
                    <button class="btn btn-secondary my-2 my-sm-0" type="submit">
                        <font style="vertical-align: inherit;">
                            <font style="vertical-align: inherit;">Búsqueda</font>
                        </font>
                    </button>
                </form>
            </div>
        </div>
    </nav>
    
    <a href="https://api.whatsapp.com/send?phone=992999877" class="btn-wsp" target="_blank"> 
    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-whatsapp" width="40" height="40" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M3 21l1.65 -3.8a9 9 0 1 1 3.4 2.9l-5.05 .9" />
                <path d="M9 10a0.5 .5 0 0 0 1 0v-1a0.5 .5 0 0 0 -1 0v1a5 5 0 0 0 5 5h1a0.5 .5 0 0 0 0 -1h-1a0.5 .5 0 0 0 0 1" />
            </svg>
        <i class="icon-whatsapp"></i>
        
    </a>
    <div class="container">
        <br />
        <div class="row">